#include "display.h"

ChessDisplay::~ChessDisplay(){}
